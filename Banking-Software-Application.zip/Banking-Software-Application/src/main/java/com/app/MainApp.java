package com.app;

import java.util.Scanner;

import com.service.BankAccountService;
import com.service.BankTransactionService;

public class MainApp {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		BankAccountService bankAccountService = new BankAccountService();
		BankTransactionService bankTransactionService = new BankTransactionService();
		
		String creationMsg = "";
		
		System.out.println("Please Enter Below Values :: ");
		System.out.println("1. Login \t 2. Create Bank Account \t 3.Exit Application");
		
		int val = scanner.nextInt();
		
		if(val == 1) {
			
			System.out.println("Enter Username :: ");
			String userName = scanner.next();
			
			System.out.println("Enter Password :: ");
			String password = scanner.next();
			
			boolean userFlag = bankAccountService.verifyUserName(userName);
			boolean passFlag = bankAccountService.verifyPassword(password);
			
			String accountNumber = bankAccountService.getAccountNo(userName);
			
			if(userFlag && passFlag) {
				System.out.println("Please Enter Below Values :: ");
				System.out.println("1 for View current Balance \t 2 for Deposit Amount \t 3 for Transfer amount \t 4 for View Transactions \t "
						+ "5 for Update Contact details");
				int val1 = scanner.nextInt();
				if(val1 == 1) {
					String viewCurrentBalance = bankTransactionService.viewCurrentBalance(userName, accountNumber);
					System.out.println("View current Balance :: " + viewCurrentBalance);
				} else if (val1 == 2) {
					
					System.out.println("Amount to be deposit ::");
					long longDepositAmount = scanner.nextLong();
										
					String depositAmount = bankTransactionService.depositAmount(userName, accountNumber, longDepositAmount);
				} else if (val1 == 3) {
					
					System.out.println("Amount to be transfer ::");
					long longTransferAmount = scanner.nextLong();
					
					System.out.println("Amount to be Transfer into Account No::");
					long longTransferAccountNo = scanner.nextLong();
					
					String abc = bankTransactionService.transferAmount(userName, accountNumber, longTransferAmount, longTransferAccountNo);
				} else if(val1 == 4) {
					//bankTransactionService.viewTransaction(userName, accountNumber);
				} else if (val1 == 5) {
					//bankTransactionService.updateContactDetails(userName, accountNumber);
				} else {
					System.out.println("Invalid Number Selection!!!");
				}
				
			} else {
				System.out.println("Invalid Username or Password!!!");
			}
			
		} else if (val == 2) {
			
			while (true) {
			
				System.out.println("Enter Name :: ");
				String Name = scanner.next();
				
				System.out.println("Enter Email-Id :: ");
				String EmailId = scanner.next();
				
				System.out.println("Enter Mobile Number :: ");
				String MobileNumber = scanner.next();
				
				System.out.println("Enter Date Of Birth :: ");
				String DateOfBirth = scanner.next();
				
				System.out.println("Enter Pan Number :: ");
				String PanNumber = scanner.next();
				
				System.out.println("Enter Aadhar Number :: ");
				String AadharNumber = scanner.next();
				
				System.out.println("Enter Postal Address :: ");
				String PostalAddress = scanner.next();
				
				System.out.println("Enter Aadhar Number :: ");
				String UserName = scanner.next();
				
				System.out.println("Enter Postal Address :: ");
				String Password = scanner.next();
					
				creationMsg = bankAccountService.createUserAccount(Name, EmailId, MobileNumber, DateOfBirth, PanNumber, AadharNumber, PostalAddress, 
						UserName, Password);
				if(creationMsg.equalsIgnoreCase("SUCCESS")) {
					System.out.println("User Account Created Successfully!!!");
					System.out.println();
					System.out.println("Do you to create another");
					
				} else {
					System.out.println("Error while creating User Account!!!");
				}
				
			}
			
			
		} else if (val == 3) {
			
			System.out.println("Exiting from Application!!");
			System.exit(0);
			
		} else {
			
			System.out.println("Invalid option selection!!");
			System.exit(0);
			
		}

	}

}
