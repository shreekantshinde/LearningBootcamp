package com.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.app.DbConnection;

public class BankTransactionRepo {

	public String viewCurrentBalance(String userName, String accountNumber) {

		DbConnection connection = null;
		Connection conObj = null;
		PreparedStatement pstmt = null;
		long viewBalance = 0;
		try {

			connection = new DbConnection();
			conObj = connection.getConnection();

			pstmt = conObj.prepareStatement(
					"SELECT MIN(ROWNUM), CURRENT_BALANCE FROM USER_TRANSACTION WHERE USERNAME = ? AND ACCOUNT_NO = ? "
							+ "HAVING ROWNUM = 1 ORDER BY TRANSACTION_DATE DESC");
			pstmt.setString(1, userName);
			pstmt.setString(2, accountNumber);

			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				viewBalance = rs.getLong(2);
			}

			if (rs != null) {
				rs.close();
				rs = null;
			}

			if (pstmt != null) {
				pstmt.close();
				pstmt = null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception while checking balance data :: " + e.toString());
			return "ERROR";
		}

		return String.valueOf(viewBalance);
	}

	public String depositAmount(String userName, String accountNumber, long longDepositAmount) {
		DbConnection connection = null;
		Connection conObj = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String currentBalance = "";
		try {
			connection = new DbConnection();
			conObj = connection.getConnection();
			
			pstmt = conObj.prepareStatement("SELECT MAX(ACCOUNT_NO) FROM USER_ACCOUNT");
			
			rs = pstmt.executeQuery();
			long accountNo = 0;
			
			if (rs.next()) {
				if (accountNo >= 0) {
					accountNo++;
				}
			} else {
				accountNo++;
			}

			if (rs != null) {
				rs.close();
				rs = null;
			}
			
			if (pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
			
			pstmt = conObj.prepareStatement("SELECT CURRENT_BALANCE FROM USER_TRANSACTION WHERE ACCOUNT_NO = ? AND USERNAME = ? "
					+ "ORDER BY TRANSACTION_DATE DESC");
			pstmt.setString(1, accountNumber);
			pstmt.setString(2, userName);
			
			rs = pstmt.executeQuery();
			while (rs.next()) {
				currentBalance = rs.getString(1) != null ? rs.getString(1) : ""; 
				break;
			}
			
			if (rs != null) {
				rs.close();
				rs = null;
			}

			if (pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
			
			pstmt = conObj.prepareStatement("INSERT INTO USER_TRANSACTION (ACCOUNT_NO,  USERNAME, CURRENT_BALANCE, CREDIT_AMOUNT, "
					+ "CREDIT_TRANSACTION, VIEW_CREDITED_TRANSACTION, TRANSACTION_DATE, TRANSACTION_ID)  VALUES (?, ?, ?, ?, ?, ?, ?, SYSDATE) ");
			pstmt.setString(1, accountNumber);
			pstmt.setString(2, userName);
			pstmt.setString(3, String.valueOf(longDepositAmount + Long.parseLong(currentBalance)));
			pstmt.setString(4, String.valueOf(longDepositAmount));
			pstmt.setString(5, String.valueOf(longDepositAmount));
			pstmt.setString(6, "CREDIT");
			pstmt.setString(7, String.valueOf(accountNo));
			
			int val = pstmt.executeUpdate();
			System.out.println("val :: " + val);
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception while Inserting data :: " + e.toString());
			return "ERROR";
		} finally {
			try {

				if (rs != null) {
					rs.close();
					rs = null;
				}
				
				if (pstmt != null) {
					pstmt.close();
					pstmt = null;
				}

				if (conObj != null) {
					conObj.close();
					conObj = null;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return "SUCCESS";
	}

	public String transferAmount(String userName, String accountNumber, long longTransferAmount,
			long longTransferAccountNo) {
		// TODO Auto-generated method stub
		return null;
	}

}
