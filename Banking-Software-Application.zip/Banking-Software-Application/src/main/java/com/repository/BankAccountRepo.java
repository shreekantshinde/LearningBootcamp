package com.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.app.DbConnection;
import com.model.BankCustomerAcc;

public class BankAccountRepo {

	public String insertRecord(BankCustomerAcc bankCustomerAcc) {
		DbConnection connection = null;
		Connection conObj = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {

			connection = new DbConnection();
			conObj = connection.getConnection();

			pstmt = conObj.prepareStatement("SELECT COUNT(*) FROM USER_ACCOUNT WHERE USERNAME = ?");
			pstmt.setString(1, bankCustomerAcc.getUserName());

			rs = pstmt.executeQuery();

			if (rs.next()) {
				String count = rs.getString(1);
				System.out.println("USERNAME IS ALREADY PRESENT :: " + count);
				return "Username is already present!!!";
			}

			if (rs != null) {
				rs.close();
				rs = null;
			}
			
			if (pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
			
			pstmt = conObj.prepareStatement("SELECT COUNT(*) FROM USER_ACCOUNT WHERE MOBILE_NO = ? AND PAN_NO = ? AND AADHAR_NO = ? "
					+ "AND EMAIL_ID = ?");
			pstmt.setString(1, bankCustomerAcc.getMobileNumber());
			pstmt.setString(2, bankCustomerAcc.getPanNumber());
			pstmt.setString(3, bankCustomerAcc.getAadharNumber());
			pstmt.setString(4, bankCustomerAcc.getEmailId());
			
			rs = pstmt.executeQuery();

			if (rs.next()) {
				String count = rs.getString(1);
				System.out.println("USERNAME IS ALREADY PRESENT :: " + count);
				return "Username is already present!!!";
			}

			if (rs != null) {
				rs.close();
				rs = null;
			}

			if (pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
			
			pstmt = conObj.prepareStatement("SELECT MAX(ACCOUNT_NO) FROM USER_ACCOUNT");
			
			rs = pstmt.executeQuery();
			long accountNo = 0;
			
			if (rs.next()) {
				if (accountNo >= 0) {
					accountNo++;
				}
			} else {
				accountNo++;
			}

			if (rs != null) {
				rs.close();
				rs = null;
			}
			
			if (pstmt != null) {
				pstmt.close();
				pstmt = null;
			}

			pstmt = conObj.prepareStatement("INSERT INTO USER_ACCOUNT (NAME, EMAIL_ID, MOBILE_NO, DATE_OF_BIRTH,"
					+ " PAN_NO, AADHAR_NO, POSTAL_ADDR, USERNAME, PASSWORD, ACCOUNT_NO) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			pstmt.setString(1, bankCustomerAcc.getName());
			pstmt.setString(2, bankCustomerAcc.getEmailId());
			pstmt.setString(3, bankCustomerAcc.getMobileNumber());
			pstmt.setString(4, bankCustomerAcc.getDateOfBirth());
			pstmt.setString(5, bankCustomerAcc.getPanNumber());
			pstmt.setString(6, bankCustomerAcc.getAadharNumber());
			pstmt.setString(7, bankCustomerAcc.getPostalAddress());
			pstmt.setString(8, bankCustomerAcc.getUserName());
			pstmt.setString(9, bankCustomerAcc.getPassword());
			pstmt.setLong(10, accountNo);

			int val = pstmt.executeUpdate();
			System.out.println("val :: " + val);

			return "SUCCESS";
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Exception while Inserting data :: " + e.toString());
			return "ERROR";
		} finally {
			try {

				if (rs != null) {
					rs.close();
					rs = null;
				}
				
				if (pstmt != null) {
					pstmt.close();
					pstmt = null;
				}

				if (conObj != null) {
					conObj.close();
					conObj = null;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public boolean verifyUserName(String userName) {

		DbConnection connection = null;
		Connection conObj = null;
		PreparedStatement pstmt = null;
		try {
			connection = new DbConnection();
			conObj = connection.getConnection();
			pstmt = conObj.prepareStatement("SELECT COUNT(*) FROM USER_ACCOUNT WHERE USERNAME = ?");
			pstmt.setString(1, userName);

			int iCount = pstmt.executeUpdate();
			if (iCount == 1) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception while getting User Name :: " + e.toString());
			return false;
		} finally {
			try {

				if (pstmt != null) {
					pstmt.close();
					pstmt = null;
				}

				if (conObj != null) {
					conObj.close();
					conObj = null;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}

	public boolean verifyPassword(String password) {

		DbConnection connection = null;
		Connection conObj = null;
		PreparedStatement pstmt = null;
		try {
			connection = new DbConnection();
			conObj = connection.getConnection();
			pstmt = conObj.prepareStatement("SELECT COUNT(*) FROM USER_ACCOUNT WHERE PASSWORD = ?");
			pstmt.setString(1, password);

			int iCount = pstmt.executeUpdate();
			if (iCount == 1) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception while getting Password :: " + e.toString());
			return false;
		} finally {
			try {

				if (pstmt != null) {
					pstmt.close();
					pstmt = null;
				}

				if (conObj != null) {
					conObj.close();
					conObj = null;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;

	}

	public String getAccountNo(String userName) {
		DbConnection connection = null;
		Connection conObj = null;
		PreparedStatement pstmt = null;
		String accountNo = "";
		ResultSet rs = null;
		try {
			connection = new DbConnection();
			conObj = connection.getConnection();
			pstmt = conObj.prepareStatement("SELECT ACCOUNT_NO FROM USER_ACCOUNT WHERE USERNAME = ?");
			pstmt.setString(1, userName);

			rs = pstmt.executeQuery();
			if (rs.next()) {
				accountNo = rs.getString(1) != null ? rs.getString(1) : "";
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception while getting User Name :: " + e.toString());
			return "ERROR";
		} finally {
			try {
				
				if (rs != null) {
					rs.close();
					rs = null;
				}

				if (pstmt != null) {
					pstmt.close();
					pstmt = null;
				}

				if (conObj != null) {
					conObj.close();
					conObj = null;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return accountNo;
	}

}
