package com.model;

public class BankCustomerAcc {

	private String Name;
	private String UserName;
	private String Password;
	private String EmailId;
	private String MobileNumber;
	private String DateOfBirth;
	private String PanNumber;
	private String AadharNumber;
	private String PostalAddress;
	
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		this.Name = name;
	}
	
	public String getUserName() {
		return UserName;
	}
	
	public void setUserName(String userName) {
		this.UserName = userName;
	}
	
	public String getPassword() {
		return Password;
	}
	
	public void setPassword(String password) {
		this.Password = password;
	}
	
	public String getEmailId() {
		return EmailId;
	}
	public void setEmailId(String emailId) {
		this.EmailId = emailId;
	}
	
	public String getMobileNumber() {
		return MobileNumber;
	}
	
	public void setMobileNumber(String mobileNumber) {
		this.MobileNumber = mobileNumber;
	}
	
	public String getDateOfBirth() {
		return DateOfBirth;
	}
	
	public void setDateOfBirth(String dateOfBirth) {
		this.DateOfBirth = dateOfBirth;
	}
	
	public String getPanNumber() {
		return PanNumber;
	}
	
	public void setPanNumber(String panNumber) {
		this.PanNumber = panNumber;
	}
	
	public String getAadharNumber() {
		return AadharNumber;
	}
	
	public void setAadharNumber(String aadharNumber) {
		this.AadharNumber = aadharNumber;
	}
	
	public String getPostalAddress() {
		return PostalAddress;
	}
	
	public void setPostalAddress(String postalAddress) {
		this.PostalAddress = postalAddress;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((AadharNumber == null) ? 0 : AadharNumber.hashCode());
		result = prime * result + ((DateOfBirth == null) ? 0 : DateOfBirth.hashCode());
		result = prime * result + ((EmailId == null) ? 0 : EmailId.hashCode());
		result = prime * result + ((MobileNumber == null) ? 0 : MobileNumber.hashCode());
		result = prime * result + ((Name == null) ? 0 : Name.hashCode());
		result = prime * result + ((PanNumber == null) ? 0 : PanNumber.hashCode());
		result = prime * result + ((Password == null) ? 0 : Password.hashCode());
		result = prime * result + ((PostalAddress == null) ? 0 : PostalAddress.hashCode());
		result = prime * result + ((UserName == null) ? 0 : UserName.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BankCustomerAcc other = (BankCustomerAcc) obj;
		if (AadharNumber == null) {
			if (other.AadharNumber != null)
				return false;
		} else if (!AadharNumber.equals(other.AadharNumber))
			return false;
		if (DateOfBirth == null) {
			if (other.DateOfBirth != null)
				return false;
		} else if (!DateOfBirth.equals(other.DateOfBirth))
			return false;
		if (EmailId == null) {
			if (other.EmailId != null)
				return false;
		} else if (!EmailId.equals(other.EmailId))
			return false;
		if (MobileNumber == null) {
			if (other.MobileNumber != null)
				return false;
		} else if (!MobileNumber.equals(other.MobileNumber))
			return false;
		if (Name == null) {
			if (other.Name != null)
				return false;
		} else if (!Name.equals(other.Name))
			return false;
		if (PanNumber == null) {
			if (other.PanNumber != null)
				return false;
		} else if (!PanNumber.equals(other.PanNumber))
			return false;
		if (Password == null) {
			if (other.Password != null)
				return false;
		} else if (!Password.equals(other.Password))
			return false;
		if (PostalAddress == null) {
			if (other.PostalAddress != null)
				return false;
		} else if (!PostalAddress.equals(other.PostalAddress))
			return false;
		if (UserName == null) {
			if (other.UserName != null)
				return false;
		} else if (!UserName.equals(other.UserName))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "BankCustomerAcc [Name=" + Name + ", UserName=" + UserName + ", Password=" + Password + ", EmailId="
				+ EmailId + ", MobileNumber=" + MobileNumber + ", DateOfBirth=" + DateOfBirth + ", PanNumber="
				+ PanNumber + ", AadharNumber=" + AadharNumber + ", PostalAddress=" + PostalAddress + "]";
	}
	
}
