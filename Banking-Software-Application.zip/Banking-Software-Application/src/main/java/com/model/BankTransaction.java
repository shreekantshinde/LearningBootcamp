package com.model;

import java.util.Date;

public class BankTransaction {

	private String AccountNumber;
	private String Username;
	private String CurrentBalance;
	private String CreditedAmount;
	private String DebitedAmount;
	private String TransferAmount;
	private String TransferAmountAccountNo;
	private String ViewCrTransaction;
	private String ViewDrTransaction;
	private Date date;
	
	public String getAccountNumber() {
		return AccountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		AccountNumber = accountNumber;
	}
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getCurrentBalance() {
		return CurrentBalance;
	}
	public void setCurrentBalance(String currentBalance) {
		CurrentBalance = currentBalance;
	}
	public String getCreditedAmount() {
		return CreditedAmount;
	}
	public void setCreditedAmount(String creditedAmount) {
		CreditedAmount = creditedAmount;
	}
	public String getDebitedAmount() {
		return DebitedAmount;
	}
	public void setDebitedAmount(String debitedAmount) {
		DebitedAmount = debitedAmount;
	}
	public String getTransferAmount() {
		return TransferAmount;
	}
	public void setTransferAmount(String transferAmount) {
		TransferAmount = transferAmount;
	}
	public String getTransferAmountAccountNo() {
		return TransferAmountAccountNo;
	}
	public void setTransferAmountAccountNo(String transferAmountAccountNo) {
		TransferAmountAccountNo = transferAmountAccountNo;
	}
	public String getViewCrTransaction() {
		return ViewCrTransaction;
	}
	public void setViewCrTransaction(String viewCrTransaction) {
		ViewCrTransaction = viewCrTransaction;
	}
	public String getViewDrTransaction() {
		return ViewDrTransaction;
	}
	public void setViewDrTransaction(String viewDrTransaction) {
		ViewDrTransaction = viewDrTransaction;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
}
