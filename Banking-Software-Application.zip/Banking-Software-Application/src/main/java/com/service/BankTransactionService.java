package com.service;

import com.repository.BankTransactionRepo;

public class BankTransactionService {

	private BankTransactionRepo bankTransactionRepo = new BankTransactionRepo();

	public BankTransactionService() {
	}

	public BankTransactionService(BankTransactionRepo bankTransactionRepo) {
		super();
		this.bankTransactionRepo = bankTransactionRepo;
	}

	public String viewCurrentBalance(String userName, String accountNumber) {

		return bankTransactionRepo.viewCurrentBalance(userName, accountNumber);
	}

	public String depositAmount(String userName, String accountNumber, long longDepositAmount) {
		return bankTransactionRepo.depositAmount(userName, accountNumber, longDepositAmount);
	}

	public String transferAmount(String userName, String accountNumber, long longTransferAmount,
			long longTransferAccountNo) {
		return bankTransactionRepo.transferAmount(userName, accountNumber, longTransferAmount, longTransferAccountNo);

	}

}
