package com.service;

import com.model.BankCustomerAcc;
import com.repository.BankAccountRepo;

public class BankAccountService {
	
	public BankAccountService() {}
	
	public BankAccountService(BankAccountRepo bankAccountRepo) {
		super();
		this.bankAccountRepo = bankAccountRepo;
	}

	private BankAccountRepo bankAccountRepo = new BankAccountRepo();
	
	public BankAccountRepo getBankAccountRepo() {
		return bankAccountRepo;
	}

	public void setBankAccountRepo(BankAccountRepo bankAccountRepo) {
		this.bankAccountRepo = bankAccountRepo;
	}

	public String createUserAccount(String name, String emailId, String mobileNumber, String dateOfBirth,
			String panNumber, String aadharNumber, String postalAddress, String userName, String password) {

		BankCustomerAcc bankCustomerAcc =  new BankCustomerAcc();
		
		bankCustomerAcc.setName(name);
		bankCustomerAcc.setEmailId(emailId);
		bankCustomerAcc.setMobileNumber(mobileNumber);
		bankCustomerAcc.setDateOfBirth(dateOfBirth);
		bankCustomerAcc.setPanNumber(panNumber);
		bankCustomerAcc.setAadharNumber(aadharNumber);
		bankCustomerAcc.setPostalAddress(postalAddress);
		bankCustomerAcc.setUserName(userName);
		bankCustomerAcc.setPassword(password);
		
		String strVal = bankAccountRepo.insertRecord(bankCustomerAcc);
		
		return strVal;
	}

	public boolean verifyUserName(String userName) {
		
		return bankAccountRepo.verifyUserName(userName);
	}

	public boolean verifyPassword(String password) {
		
		return bankAccountRepo.verifyPassword(password);
	}

	public String getAccountNo(String userName) {
		return bankAccountRepo.getAccountNo(userName);
	}

}