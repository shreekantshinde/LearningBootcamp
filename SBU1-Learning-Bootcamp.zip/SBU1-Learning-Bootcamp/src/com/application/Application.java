package com.application;

public class Application {
	
	public void open() {
		System.out.println("Application.open() method call");
	}
	
	public void close() {
		System.out.println("Application.close() method call");
	}

}
