package �om.app;

class Address {

	private String addressLine;
	private String city;
	
	public Address(String addressLine, String city) {
		super();
		this.addressLine = addressLine;
		this.city = city;
	}
	public String getAddressLine() {
		return addressLine;
	}
	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "Address [addressLine=" + addressLine + ", city=" + city + "]";
	}
	
}

class CustAccount {
	int account_number;
	String name;
	Address address;
	
	public CustAccount() {}
	
	public CustAccount(int account_number, String name, Address address) {
		this.account_number = account_number;
		this.name = name;
		this.address = address;
	}
	
	public int getAccount_number() {
		return account_number;
	}

	public void setAccount_number(int account_number) {
		this.account_number = account_number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + account_number;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustAccount other = (CustAccount) obj;
		if (account_number != other.account_number)
			return false;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CustAccount [account_number=" + account_number + ", name=" + name + ", address=" + address + "]";
	}

		
}

public class ShallowDeepCloningDemo {

	public static void main(String[] args) {
		Address address = new Address("Marol", "Andheri");
		CustAccount custAccount = new CustAccount(1, "Sandesh", address);
		
		CustAccount custAccount2 = custAccount;
		custAccount.name = "Shreekant";
		
		System.out.println("shallow cloning custAccount2 :: " + custAccount2);
		
		System.out.println("***********************************************************************************");
		
		Address address1 = new Address("J P Nagar", "Goregaon");
		CustAccount custAccount3 = new CustAccount(2, "Komal", address1);
		CustAccount custAccount4 = new CustAccount();
		custAccount4.name = "Smita";
		
		System.out.println("deep cloning custAccount3 :: " + custAccount3.name);
	}
	
	
	
}
