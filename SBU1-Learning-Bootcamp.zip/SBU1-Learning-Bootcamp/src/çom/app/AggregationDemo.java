package �om.app;

import java.util.ArrayList;
import java.util.List;

class Professor {

	private String name;
	private int id;
	private String dept;

	Professor(String name, int id, String dept){
		super();
		this.name = name;
		this.id = id;
		this.dept = dept;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	@Override
	public String toString() {
		return "Professor [name=" + name + ", id=" + id + ", dept=" + dept + "]";
	}
	
}

class Department {
	private String name;
	private List<Professor> professors;
	Department(String name, List<Professor> professors) {
		super();
		this.name = name;
		this.professors = professors;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Professor> getProfessors() {
		return professors;
	}

	public void setProfessors(List<Professor> professors) {
		this.professors = professors;
	}

}

class University {

	String instituteName;
	private List<Department> departments;

	University(String instituteName,List<Department> departments) {
		super();
		this.instituteName = instituteName;
		this.departments = departments;
	}

	public String getInstituteName() {
		return instituteName;
	}

	public void setInstituteName(String instituteName) {
		this.instituteName = instituteName;
	}

	public List<Department> getDepartments() {
		return departments;
	}

	public void setDepartments(List<Department> departments) {
		this.departments = departments;
	}

	public int getTotalStudentsInInstitute()
	{
		int noOfStudents = 0;
		List<Professor> professors;

		for (Department dept : departments) {
			professors = dept.getProfessors();

			for (Professor s : professors) {
				noOfStudents++;
			}
		}

		return noOfStudents;
	}
}

class AggregationDemo {

	public static void main(String[] args) {
		Professor p1 = new Professor("Shreekant", 1, "CSE");
		Professor p2 = new Professor("Smita", 2, "CSE");
		Professor p3 = new Professor("Sandesh", 1, "EE");
		Professor p4 = new Professor("Rahul", 2, "EE");

		// Creating a List of CSE Students
		List<Professor> cse_professors = new ArrayList<>();

		// Adding CSE professors
		cse_professors.add(p1);
		cse_professors.add(p2);

		// Creating a List of EE Students
		List<Professor> ee_professors = new ArrayList<>();

		// Adding EE professors
		ee_professors.add(p3);
		ee_professors.add(p4);

		// Creating objects of EE and CSE class inside
		// main()
		Department CSE = new Department("CSE", cse_professors);
		Department EE = new Department("EE", ee_professors);

		List<Department> departments = new ArrayList<>();
		departments.add(CSE);
		departments.add(EE);

		// Lastly creating an instance of Institute
		University university = new University("BITS", departments);

		// Display message for better readability
		System.out.print("Total professors in university: ");

		// Calling method to get total number of professors
		// in university and printing on console
		System.out.print(university.getTotalStudentsInInstitute());
	}
}

