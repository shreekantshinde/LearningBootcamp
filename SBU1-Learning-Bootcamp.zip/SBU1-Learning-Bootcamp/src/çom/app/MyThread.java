package çom.app;

class PrintChar extends Thread {
	
	public PrintChar(String tname) {
		setName(tname);
	}
	
	public void run() {
		for (int i = 0; i < MyThread.str.length(); i++) {
			System.out.println(Thread.currentThread().getName()+" Thread..."+MyThread.str.charAt(MyThread.cindex++));
			try {
				Thread.sleep(60);
			} catch (InterruptedException ie) {
				ie.printStackTrace();
				System.out.println(ie.getMessage());
			} finally {
				
			}
		}
	}
}

public class MyThread {
	static String str = "Hello, am explroign mutlithreadin g...";
	static int cindex = 0;
	
	public static void main(String[] args) throws InterruptedException {
		PrintChar pc1 = new PrintChar("Beta");
		
		pc1.start();
		PrintChar pc2 = new PrintChar("Gamma");

		pc2.start();
		pc1.join();
		pc2.join();
		System.out.println("-------------------");
		
		System.out.println(pc1.getState().name()+"|"+Thread.currentThread().getState().name());
	}
}