package �om.app;

import java.util.HashSet;

public class ArrayListCustomDemo {
	
	public static void main(String[] args) {
		XyzList<String> cArrayList = new XyzList<String>();
		cArrayList.add("abc");
		cArrayList.add("abc");
		cArrayList.add("abc");

		System.out.println(cArrayList);

		HashSet<String> hss = new HashSet<String>(cArrayList);
		System.out.println(hss);
	}
}
