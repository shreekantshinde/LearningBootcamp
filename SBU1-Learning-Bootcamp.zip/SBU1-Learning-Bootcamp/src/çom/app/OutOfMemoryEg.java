package �om.app;

class MyOwnClass{
	int[] arr = new int[100000000];
}

public class OutOfMemoryEg {

	public static void main(String[] args) {
		int i = 0;
		try {
			MyOwnClass[] mcarr = new MyOwnClass[100000000];
			for(;i<mcarr.length;i++) {
				mcarr[i] = new MyOwnClass();
			}
		}
		catch (OutOfMemoryError e) {
			System.out.println("OutMemory Iteration : " + i);
		}
	}

}
