package �om.app;

import java.util.*;

//Class 1
//Student class
class Student {

	String name;
	String dept;
	
	// Constructor of student class
	Student(String name, String dept){
		super();
		this.name = name;
		this.dept = dept;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}
}

class Institute {
	// Attributes of Department class
	private List<Student> students;
	Institute(List<Student> students){
		super();
		this.students = students;
	}

	// Method of Department class
	public List<Student> getStudents(){
		return students;
	}
}

//main class
public class CompositionDemo {

	// main driver method
	public static void main(String[] args)
	{
		// Creating object of Student class inside main()
		Student s1 = new Student("Shreekant", "ECE");
		Student s2 = new Student("Smita", "CSE");
		Student s3 = new Student("Sandesh", "EE");
		Student s4 = new Student("Rahul", "EE");

		// Creating a List of CSE Students
		List<Student> students = new ArrayList<>();

		// Adding students
		students.add(s1);
		students.add(s2);
		students.add(s3);
		students.add(s4);

		// Creating objects of EE and CSE class inside
		// main()
		Institute institute = new Institute(students);

		List<Student> studentList = institute.getStudents();

		//studentList.stream().map(student -> student).forEach("Student Name :: " + Student::getName + " -->> Department :: " + Student :: getDept);
		
		for(Student student : studentList) {
			System.out.println("Student Name :: " + student.name + " -->> Department :: " + student.dept);
		}
	}
}

