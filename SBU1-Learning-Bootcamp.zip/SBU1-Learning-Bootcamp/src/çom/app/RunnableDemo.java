package �om.app;

public class RunnableDemo {

	public static void main(String[] args) {
		Runnable runnable = () -> {
			for(int i = 0; i < 5; i++) {
				//System.out.println("run() call");
			}
			
		};
		Thread thread = new Thread(runnable);
		thread.start();
		System.out.println();

	}

}
