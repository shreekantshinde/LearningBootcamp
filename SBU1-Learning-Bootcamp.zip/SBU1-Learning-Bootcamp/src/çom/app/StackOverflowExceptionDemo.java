package �om.app;

public class StackOverflowExceptionDemo {

	public static void main(String[] args) {
		int i = 0;
		try {
		
			for(;i < args.length;i++) {
				String [] strArr = new String[1000000];
				StackOverflowExceptionDemo.main(strArr);
			}
			
		} catch (Throwable e) {
			System.out.println("Number of Iteration :: " + i);
		}
		/* below for loop gives :- Exception in thread "main" java.lang.OutOfMemoryError: Java heap space
		 * for(int i = 0; i< strArr.length; i++) {
			StackOverflowExceptionDemo.main(strArr[i]);
		}*/
	}

}
