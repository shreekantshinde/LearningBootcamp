package �om.app;

class state {
	 public Boolean flag = false;
	    public int stateCode = 0;
	    public String stateMsg = "";

	    public void raise(int code, String msg){
	        this.stateCode = code;
	        this.stateMsg = msg;
	    }
}

class Chaining1{
	private int val1;
	private long val2;
	
	Chaining1(){
		System.out.println("Calling The Constructor Chaining2");
	}
	
	public Chaining1 met1(int val1) {
		this.val1 = val1;
		return this;
	}
	public Chaining1 met2(long val2) {
		this.val2 = val2;
		return this;
	}
	
	public void showChaining1() {
		System.out.println("show :: " + val1 + " " + val2);
	}
	
}

class Chaining2{
	private float val3;
	private double val4;
	
	Chaining2(){
		System.out.println("Calling The Constructor Chaining2");
	}
	
	public Chaining2 met3(float val3) {
		this.val3 = val3;
		return this;
	}
	public Chaining2 met4(double val4) {
		this.val4 = val4;
		return this;
	}
	
	public void showChaining2() {
		System.out.println("show :: " + val3 + " " + val4);
	}
	
}

public class MethodChainingDemo2 {

	public static void main(String[] args) {
		new Chaining1().met1(10).met2(20l).showChaining1();
	}
	
}
