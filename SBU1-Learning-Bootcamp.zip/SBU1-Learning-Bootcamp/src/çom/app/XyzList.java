package �om.app;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

class XyzList<T> extends ArrayList<T> {

	/**
	 * 
	 */
	public static final long serialVersionUID = 3911498106033831169L;

	public XyzList() {

	}

	// method to add element at the end of the list
	public boolean addElement(T obj) {
		boolean added = false;
		int num_of_occurrences = Collections.frequency(this, obj);
		if (num_of_occurrences < 2) {
			added = super.add(obj);
		}

		return added;
	}

	// method to add element at a specific index, of the list
	public boolean addElement(int index, T obj) {
		boolean added = false;
		int num_of_occurrences = Collections.frequency(this, obj);
		if (num_of_occurrences < 2) {
			super.add(index, obj);
		}

		return added;
	}

	@Override
	public boolean add(T obj) {
		return addElement(obj);
	}

	@Override
	public void add(int index, T obj) {
		addElement(obj);
	}

	@Override
	public boolean addAll(Collection<? extends T> coll) {
		boolean added_all_elements = true;
		for (T element : coll) {
			added_all_elements = addElement(element);
		}

		return added_all_elements;
	}

	@Override
	public boolean addAll(int index, Collection<? extends T> coll) {
		boolean added_all_elements = true;
		for (T element : coll) {
			added_all_elements = addElement(index, element);
		}

		return added_all_elements;
	}

	@Override
	public T set(int index, T obj) {
		int num_of_occurrences = Collections.frequency(this, obj);
		T pElement = super.get(index);

		if (num_of_occurrences < 2) {
			super.set(index, obj);
		}

		return pElement;
	}

}
