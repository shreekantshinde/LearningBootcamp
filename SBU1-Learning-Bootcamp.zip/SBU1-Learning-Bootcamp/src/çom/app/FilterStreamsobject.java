package �om.app;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class FilterStreamsobject {

	public static void main(String[] args) {
		ArrayList<String> als = new ArrayList<>();
		als.add("Bangalore");
		als.add("Chennai");
		als.add("Hyderabad");
		als.add("Manglore");
		als.add("Madurai");
		als.add("Mumbai");
		
		List<String>filteredCities = als.stream().filter(str -> str.startsWith("M")).sorted(Collections.reverseOrder()).collect(Collectors.toList());
		System.out.println("filteredCities :: " + filteredCities);

	}

}
