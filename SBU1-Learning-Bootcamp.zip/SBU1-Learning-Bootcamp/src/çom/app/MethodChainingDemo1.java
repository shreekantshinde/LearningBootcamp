package �om.app;

class Chaining{
	private int val1;
	private long val2;
	private float val3;
	private double val4;
	
	Chaining(){
		System.out.println("Calling The Constructor");
	}
	
	public Chaining met1(int val1) {
		this.val1 = val1;
		return this;
	}
	public Chaining met2(long val2) {
		this.val2 = val2;
		return this;
	}
	
	public Chaining met3(float val3) {
		this.val3 = val3;
		return this;
	}
	public Chaining met4(double val4) {
		this.val4 = val4;
		return this;
	}
	
	
	public void show() {
		System.out.println("show :: " + val1 + " " + val2 + " " + val3 + " " + val4);
	}
	
}

public class MethodChainingDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Chaining().met1(10).met2(20l).met3(30f).met4(40).show();
	}

}
