package �om.app;

import java.util.StringTokenizer;

public class TokenizationDemo {

	public static void main(String[] args) {
		String raw_str ="21,321,321;4324,3243,24;234,3212,3;242,13,21;123,2134,32";
		StringTokenizer token = new StringTokenizer(raw_str, ",");
		
		while (token.hasMoreElements()) {
			String str = token.nextToken(",");
			StringTokenizer token1 = new StringTokenizer(str, ";");
			
			while (token1.hasMoreElements()) {
				System.out.println(token1.nextToken());
			}
		}

	}

}
