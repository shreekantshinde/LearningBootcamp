package �om.app;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class City {
	private String name;
	private int population;

	public City() {
	}

	public City(String name, int population) {
		super();
		this.name = name;
		this.population = population;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPopulation() {
		return population;
	}

	public void setPopulation(int population) {
		this.population = population;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		// result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + population;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		City other = (City) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (population != other.population)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "City [name=" + name + ", population=" + population + "]";
	}

}

public class HashMapDemo {
	public static void main(String[] args) {
		HashMap<String, ArrayList<City>> hsac = new HashMap<>();

		ArrayList<City> alc = new ArrayList<>();
		alc.add(new City("Bangalore", 111));
		alc.add(new City("Mysore", 123));
		alc.add(new City("Belalry", 311));
		hsac.put("Karnataka", alc);

		ArrayList<City> alca = new ArrayList<>();
		alca.add(new City("Vizag", 111));
		alca.add(new City("Tirupati", 123));
		hsac.put("AP", alca);
		
		List<ArrayList<City>> list = hsac.entrySet().stream().filter(city -> city.getKey().equals("Karnataka")).
									 map(city -> city.getValue()).collect(Collectors.toList());
		System.out.println(list);
		
		System.out.println("******************************************************");
		
		Iterator<Map.Entry<String, ArrayList<City>>> cityItr = hsac.entrySet().iterator();
		while(cityItr.hasNext()) {
			Entry<String, ArrayList<City>> entry = cityItr.next();
			System.out.println(entry.getKey() + " -> " + entry.getValue());
		}
		
		System.out.println("******************************************************");
		
		for(Map.Entry<String, ArrayList<City>> entry : hsac.entrySet()) {
			System.out.println(entry.getKey() + " -> " + entry.getValue());
		}
		
		System.out.println("******************************************************");
		
		List<ArrayList<City>> cityList = hsac.entrySet().stream().filter(city -> city.getKey().equalsIgnoreCase("AP")).map(city -> city.getValue()).flatMap(city -> Stream.of(city)).collect(Collectors.toList());
		System.out.println("cityList :: " + cityList);
	}

}
