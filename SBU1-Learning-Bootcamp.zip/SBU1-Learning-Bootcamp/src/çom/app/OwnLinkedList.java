package �om.app;

class Node<T> {
    private T i;

    Node<T> next;

    Node(T i) {
    	this.i = i;
    }
    public void set(T i) {
    	this.i = i;
    }

    public T get() {
		return i;
    }

}

public class OwnLinkedList {
	public static void main(String args[]) {
		//create elements, and assign next element
		Node<Integer> n1 = new Node<>(10);
		
		Node<Integer> n2 = new Node<>(20);
		n1.next = n2;

		Node<Integer> n3 = new Node<>(30);
		n2.next = n3;

		Node<Integer> n4 = new Node<>(40);
		n3.next = n4;

		Node<Integer> n5 = new Node<>(50);
		n4.next = n5;
		n5.next = null;

		Node<Integer> tmp = n1;
		while(tmp!=null) {
			System.out.println(tmp.get());
			tmp = tmp.next;
		}
	}
}
