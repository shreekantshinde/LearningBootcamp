package �om.todo;

import com.application.Application;

public class TodoApp extends Application {

	@Override
	public void open() {
		System.out.println("TodoApp.open() method call");
	}
	
	@Override
	public void close() {
		System.out.println("TodoApp.close() method call");
	}
	
	public static void main(String[] args) {
		Application app =  new TodoApp();
		
		app.open();
	}
	
}
